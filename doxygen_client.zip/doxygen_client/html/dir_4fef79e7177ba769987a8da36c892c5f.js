var dir_4fef79e7177ba769987a8da36c892c5f =
[
    [ "Desktop_Qt_6_9_0_MinGW_64_bit-Debug", "dir_19572e210953950637ab0e0bc42e961a.html", "dir_19572e210953950637ab0e0bc42e961a" ]
];