var searchData=
[
  ['authorization_0',['authorization',['../classauthorization.html',1,'authorization'],['../class_ui_1_1authorization.html',1,'Ui::authorization']]]
];
