var searchData=
[
  ['singleton_5fclient_0',['Singleton_client',['../class_singleton__client.html',1,'']]],
  ['singleton_5fclientdestroyer_1',['Singleton_clientDestroyer',['../class_singleton__client_destroyer.html',1,'']]]
];
