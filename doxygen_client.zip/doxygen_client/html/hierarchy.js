var hierarchy =
[
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "Singleton_client", "class_singleton__client.html", null ],
      [ "TestCaesarCipher", "class_test_caesar_cipher.html", null ],
      [ "TestHashCalculator", "class_test_hash_calculator.html", null ]
    ] ],
    [ "QT_WARNING_DISABLE_DEPRECATED::qt_meta_tag_ZN10MainWindowE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n10_main_window_e__t.html", null ],
    [ "QT_WARNING_DISABLE_DEPRECATED::qt_meta_tag_ZN10task2_hashE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n10task2__hash_e__t.html", null ],
    [ "QT_WARNING_DISABLE_DEPRECATED::qt_meta_tag_ZN12Task1_CaesarE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n12_task1___caesar_e__t.html", null ],
    [ "QT_WARNING_DISABLE_DEPRECATED::qt_meta_tag_ZN13authorizationE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n13authorization_e__t.html", null ],
    [ "QWidget", null, [
      [ "Task1_Caesar", "class_task1___caesar.html", null ],
      [ "authorization", "classauthorization.html", null ],
      [ "task2_hash", "classtask2__hash.html", null ]
    ] ],
    [ "Singleton_clientDestroyer", "class_singleton__client_destroyer.html", null ],
    [ "Ui_authorization", "class_ui__authorization.html", [
      [ "Ui::authorization", "class_ui_1_1authorization.html", null ]
    ] ],
    [ "Ui_MainWindow", "class_ui___main_window.html", [
      [ "Ui::MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ],
    [ "Ui_Task1_Caesar", "class_ui___task1___caesar.html", [
      [ "Ui::Task1_Caesar", "class_ui_1_1_task1___caesar.html", null ],
      [ "Ui::Task1_Caesar", "class_ui_1_1_task1___caesar.html", null ]
    ] ],
    [ "Ui_task2_hash", "class_ui__task2__hash.html", [
      [ "Ui::task2_hash", "class_ui_1_1task2__hash.html", null ],
      [ "Ui::task2_hash", "class_ui_1_1task2__hash.html", null ]
    ] ]
];