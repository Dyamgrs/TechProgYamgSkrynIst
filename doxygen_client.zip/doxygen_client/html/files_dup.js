var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "authorization.h", "authorization_8h_source.html", null ],
    [ "functionClient.h", "function_client_8h_source.html", null ],
    [ "mainwindow.h", "mainwindow_8h_source.html", null ],
    [ "singleton_client.h", "singleton__client_8h_source.html", null ],
    [ "task1_caesar.h", "task1__caesar_8h_source.html", null ],
    [ "task2_hash.h", "task2__hash_8h_source.html", null ]
];