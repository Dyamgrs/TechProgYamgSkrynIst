var annotated_dup =
[
    [ "QT_WARNING_DISABLE_DEPRECATED", null, [
      [ "qt_meta_tag_ZN11MyTcpServerE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n11_my_tcp_server_e__t.html", null ]
    ] ],
    [ "MyTcpServer", "class_my_tcp_server.html", null ]
];