var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "mytcpserver.h", "mytcpserver_8h_source.html", null ]
];