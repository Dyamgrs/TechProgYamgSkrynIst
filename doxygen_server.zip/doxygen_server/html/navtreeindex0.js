var NAVTREEINDEX0 =
{
"annotated.html":[0,0],
"class_my_tcp_server.html":[0,0,1],
"classes.html":[0,1],
"dir_19572e210953950637ab0e0bc42e961a.html":[1,0,0,0],
"dir_2c32d41206a938fbc221faf2a8ee7625.html":[1,0,0,0,0],
"dir_4fef79e7177ba769987a8da36c892c5f.html":[1,0,0],
"files.html":[1,0],
"hierarchy.html":[0,2],
"index.html":[],
"moc__predefs_8h_source.html":[1,0,0,0,0,0],
"mytcpserver_8h_source.html":[1,0,1],
"pages.html":[],
"struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n11_my_tcp_server_e__t.html":[0,0,0,0]
};
